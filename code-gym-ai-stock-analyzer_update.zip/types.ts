
export interface FinancialYear {
  year: number;
  revenue: number;
  grossProfit: number;
  operatingProfit: number;
  ebit: number;
  interestExpense: number;
  netIncome: number;
  totalAssets: number;
  currentAssets: number;
  totalLiabilities: number;
  currentLiabilities: number;
  longTermDebt: number;
  shareholdersEquity: number;
  sharesOutstanding: number;
  retainedEarnings: number;
  operatingCashFlow: number;
  investingCashFlow: number;
  financingCashFlow: number;
  capitalExpenditure: number;
  marketCap: number;
}

export interface StockData {
  symbol: string;
  name: string;
  sector: string;
  industry: string;
  currentPrice: number;
  financials: FinancialYear[];
}

export interface FScoreResult {
  total: number;
  details: {
    roaPositive: boolean;
    ocfPositive: boolean;
    roaImproving: boolean;
    ocfVsNetIncome: boolean;
    leverageDecreasing: boolean;
    liquidityImproving: boolean;
    sharesNoDilution: boolean;
    marginImproving: boolean;
    turnoverImproving: boolean;
  };
}

export interface ZScoreResult {
  score: number;
  a: number;
  b: number;
  c: number;
  d: number;
  e: number;
  risk: 'Safe' | 'Grey' | 'Distress';
}

export interface DuPontResult {
  year: number;
  netMargin: number;
  assetTurnover: number;
  equityMultiplier: number;
  roe: number;
}

export interface CashFlowResult {
  ocfQuality: number;
  fcf: number;
  structure: {
    operating: number;
    investing: number;
    financing: number;
  };
}

export interface AnalysisSummary {
  fScore: FScoreResult;
  zScore: ZScoreResult;
  duPont: DuPontResult[];
  cashFlow: CashFlowResult;
  isInvestable: boolean;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface AIAnalysisResponse {
  mainStrengths: string[];
  riskFactors: string[];
  monitoringMetrics: string[];
  industryOutlook: string;
  livePrice?: number;
  liveMarketCap?: string;
  sources?: GroundingSource[];
}
