
import React from 'react';
import { StockData, AnalysisSummary, AIAnalysisResponse } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, Legend, AreaChart, Area, Cell, PieChart, Pie
} from 'recharts';

interface Props {
  stock: StockData;
  analysis: AnalysisSummary;
  aiInterpretation: AIAnalysisResponse | null;
}

const AnalysisView: React.FC<Props> = ({ stock, analysis, aiInterpretation }) => {
  const latestFinancials = stock.financials[0];

  // 優先使用 AI 抓取的最新數據，若無則回退至 mock 數據
  const displayPrice = aiInterpretation?.livePrice || stock.currentPrice;
  const displayMarketCap = aiInterpretation?.liveMarketCap || `${(latestFinancials.marketCap / 1e12).toFixed(2)} 兆美元`;

  const fScoreItems = [
    { label: "ROA > 0", value: analysis.fScore.details.roaPositive },
    { label: "OCF > 0", value: analysis.fScore.details.ocfPositive },
    { label: "ROA 成長", value: analysis.fScore.details.roaImproving },
    { label: "OCF > 淨利", value: analysis.fScore.details.ocfVsNetIncome },
    { label: "負債比改善", value: analysis.fScore.details.leverageDecreasing },
    { label: "流動比改善", value: analysis.fScore.details.liquidityImproving },
    { label: "無股數稀釋", value: analysis.fScore.details.sharesNoDilution },
    { label: "毛利改善", value: analysis.fScore.details.marginImproving },
    { label: "周轉率改善", value: analysis.fScore.details.turnoverImproving },
  ];

  const zScoreData = [
    { name: '營運資本', val: analysis.zScore.a * 1.2 },
    { name: '保留盈餘', val: analysis.zScore.b * 1.4 },
    { name: 'EBIT', val: analysis.zScore.c * 3.3 },
    { name: '市值', val: analysis.zScore.d * 0.6 },
    { name: '營收', val: analysis.zScore.e * 1.0 },
  ];

  const pieData = [
    { name: '營運', value: Math.max(0, analysis.cashFlow.structure.operating) },
    { name: '投資', value: Math.max(0, Math.abs(analysis.cashFlow.structure.investing)) },
    { name: '融資', value: Math.max(0, Math.abs(analysis.cashFlow.structure.financing)) },
  ];

  const COLORS = ['#10b981', '#ef4444', '#3b82f6'];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* TradingView Style Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl overflow-hidden relative">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <svg className="w-32 h-32" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 19h20L12 2zm0 3.8L18.6 17H5.4L12 5.8z"/></svg>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-bold rounded uppercase tracking-tighter">Live Market Data</span>
              <h2 className="text-4xl font-black text-white tracking-tight">{stock.name}</h2>
            </div>
            <div className="flex items-center gap-4 text-slate-400 font-mono text-sm">
              <span className="font-bold text-indigo-400 text-lg">{stock.symbol}</span>
              <span className="text-slate-700">|</span>
              <span>{stock.industry}</span>
              <span className="text-slate-700">|</span>
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs uppercase tracking-widest text-emerald-500 font-bold">市場即時數據</span>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-8 md:text-right">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">最新報價 (Live Price)</p>
              <div className="flex items-baseline gap-2 justify-end">
                <span className="text-5xl font-black text-white leading-none tracking-tighter">
                  ${displayPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-emerald-500 font-bold text-sm">USD</span>
              </div>
            </div>
            <div className="h-10 w-px bg-slate-800 hidden md:block"></div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">總市值 (Market Cap)</p>
              <p className="text-2xl font-black text-indigo-400 tracking-tight">{displayMarketCap}</p>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap gap-4 pt-6 border-t border-slate-800/50">
           <div className={`flex items-center gap-3 px-6 py-2 rounded-full border-2 transition-all ${analysis.isInvestable ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400' : 'border-slate-700 bg-slate-800 text-slate-400'}`}>
            <div className={`w-2 h-2 rounded-full ${analysis.isInvestable ? 'bg-emerald-500 animate-ping' : 'bg-slate-500'}`} />
            <span className="text-sm font-black uppercase tracking-widest">
              {analysis.isInvestable ? '推薦進場 (Strong Signal)' : '中立觀望 (Neutral)'}
            </span>
          </div>
          <div className="px-4 py-2 bg-slate-800/50 rounded-full border border-slate-700 text-xs text-slate-400 flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            數據即時抓取於 TradingView / Google Search
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* F-Score Card */}
        <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-200">Piotroski F-Score</h3>
              <p className="text-xs text-slate-500">門檻: ≥ 5</p>
            </div>
            <span className={`text-3xl font-black ${analysis.fScore.total >= 5 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {analysis.fScore.total}<span className="text-slate-500 text-lg font-normal">/9</span>
            </span>
          </div>
          <div className="grid grid-cols-1 gap-1.5">
            {fScoreItems.map((item, i) => (
              <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-slate-950/50 hover:bg-slate-800/30 transition-colors">
                <span className="text-xs text-slate-400">{item.label}</span>
                {item.value ? (
                  <svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
                ) : (
                  <svg className="w-4 h-4 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Z-Score Card */}
        <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex justify-between items-center mb-6">
             <div>
              <h3 className="text-lg font-bold text-slate-200">Altman Z-Score</h3>
              <p className="text-xs text-slate-500">門檻: &gt; 2.5</p>
            </div>
            <div className="text-right">
              <span className={`text-3xl font-black ${analysis.zScore.risk === 'Safe' ? 'text-emerald-400' : analysis.zScore.risk === 'Grey' ? 'text-amber-400' : 'text-rose-400'}`}>
                {analysis.zScore.score.toFixed(2)}
              </span>
              <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">{analysis.zScore.risk === 'Safe' ? '安全' : '警示'} 區域</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={zScoreData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
                <Bar dataKey="val" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cash Flow Card */}
        <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-200">現金流品質</h3>
              <p className="text-xs text-slate-500">門檻: ≥ 1.2x</p>
            </div>
            <div className="text-right">
              <span className={`text-3xl font-black ${analysis.cashFlow.ocfQuality >= 1.2 ? 'text-emerald-400' : 'text-slate-300'}`}>
                {analysis.cashFlow.ocfQuality.toFixed(2)}x
              </span>
              <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">質量比率</p>
            </div>
          </div>
          <div className="flex items-center justify-center h-48">
             <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 p-4 rounded-xl bg-slate-950/50 border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500 font-bold uppercase tracking-wider">自由現金流 (FCF)</span>
              <span className="text-white font-black">${(analysis.cashFlow.fcf / 1e9).toFixed(2)}B</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Interpretation */}
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/20 p-8 rounded-3xl shadow-2xl">
        <div className="flex items-center gap-4 mb-10">
          <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-600/30">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
          </div>
          <div>
            <h3 className="text-2xl font-black text-white tracking-tight uppercase">AI 投資評估與即時數據分析</h3>
            <p className="text-slate-500 text-sm font-medium">整合最新市場資訊與歷史財報之深度洞察</p>
          </div>
        </div>

        {aiInterpretation ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-emerald-500 mb-4 flex items-center gap-2">主要優勢</h4>
                <ul className="space-y-4">
                  {aiInterpretation.mainStrengths.map((s, i) => (
                    <li key={i} className="flex gap-4 p-4 bg-slate-800/30 rounded-2xl border border-slate-700/30 text-slate-300 text-sm leading-relaxed hover:border-emerald-500/30 transition-all group">
                      <span className="text-emerald-500 font-black group-hover:scale-110 transition-transform">{i+1}</span>
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-bold text-rose-500 mb-4 flex items-center gap-2">風險因素</h4>
                <ul className="space-y-4">
                  {aiInterpretation.riskFactors.map((r, i) => (
                    <li key={i} className="flex gap-4 p-4 bg-slate-800/30 rounded-2xl border border-slate-700/30 text-slate-300 text-sm leading-relaxed hover:border-rose-500/30 transition-all group">
                      <span className="text-rose-500 font-black group-hover:scale-110 transition-transform">{i+1}</span>
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="space-y-8">
              <div className="bg-indigo-600/5 p-6 rounded-3xl border border-indigo-500/10 shadow-inner">
                <h4 className="text-lg font-bold text-indigo-400 mb-5">2年內產業趨勢看好</h4>
                <p className="text-slate-300 leading-relaxed text-sm font-medium italic">
                  "{aiInterpretation.industryOutlook}"
                </p>
              </div>
              <div>
                <h4 className="text-lg font-bold text-blue-400 mb-4">後續追蹤重點</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {aiInterpretation.monitoringMetrics.map((m, i) => (
                    <div key={i} className="px-4 py-3 bg-slate-900 rounded-xl text-xs text-slate-400 border border-slate-800 flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                      {m}
                    </div>
                  ))}
                </div>
              </div>

              {/* 數據來源網址 */}
              {aiInterpretation.sources && aiInterpretation.sources.length > 0 && (
                <div className="mt-6 pt-6 border-t border-slate-800">
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">數據來源引用 (Grounding Sources)</h4>
                  <div className="flex flex-wrap gap-2">
                    {aiInterpretation.sources.map((src, i) => (
                      <a 
                        key={i} 
                        href={src.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[10px] px-3 py-1 bg-slate-950 border border-slate-800 text-slate-400 rounded-full hover:bg-slate-800 hover:text-white transition-all flex items-center gap-2"
                      >
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                        {src.title.length > 20 ? src.title.substring(0, 20) + '...' : src.title}
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 space-y-6">
            <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
            <p className="text-slate-500 font-medium tracking-wide text-sm animate-pulse uppercase">AI 正在抓取最新市場報價與生成報告...</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisView;
