
import React, { useState, useMemo } from 'react';
import { POPULAR_STOCKS } from './constants';
import { StockData, AnalysisSummary, AIAnalysisResponse } from './types';
import { performFullAnalysis } from './services/analysisEngine';
import { getAIInterpretation } from './services/geminiService';
import AnalysisView from './components/AnalysisView';

const App: React.FC = () => {
  const [selectedStock, setSelectedStock] = useState<StockData | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisSummary | null>(null);
  const [aiInterpretation, setAiInterpretation] = useState<AIAnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const stockSummary = useMemo(() => {
    return POPULAR_STOCKS.map(stock => {
      const results = performFullAnalysis(stock);
      
      // Determine recommendation reason based on specific strengths
      let reason = "基本面穩健";
      if (results.fScore.total >= 8) {
        reason = "財務品質極其出色 (F-Score 8+)";
      } else if (results.zScore.score > 4) {
        reason = "極度安全的資產結構 (Z-Score 4+)";
      } else if (results.cashFlow.ocfQuality > 2) {
        reason = "現金流轉化率優異 (OCF 品質 2+)";
      } else if (results.duPont[0].roe > 0.4) {
        reason = "極高的股東權益回報 (ROE 40%+)";
      } else if (results.isInvestable) {
        reason = "符合所有進場篩選門檻";
      } else {
        reason = "部分指標待觀察";
      }
      
      return {
        stock,
        analysis: results,
        reason
      };
    });
  }, []);

  const handleAnalysis = async (stock: StockData) => {
    setLoading(true);
    setSelectedStock(stock);
    setAiInterpretation(null);
    
    // Step 1: Compute Frameworks
    const results = performFullAnalysis(stock);
    setAnalysis(results);
    
    // Step 2: Get AI Interpretation
    try {
      const aiResponse = await getAIInterpretation(stock, results);
      setAiInterpretation(aiResponse);
    } catch (err) {
      console.error("AI Analysis failed", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredSummary = stockSummary.filter(item => 
    item.stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.stock.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 pb-20">
      {/* Navigation */}
      <nav className="bg-slate-900/80 backdrop-blur-md border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => { setSelectedStock(null); setAnalysis(null); }}>
            <div className="bg-indigo-600 p-1.5 rounded-lg">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
              CODE GYM 股票基本面分析
            </h1>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest">AI 自動選股系統</span>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 mt-12">
        {/* Intro Section */}
        {!selectedStock && (
          <div className="text-center max-w-4xl mx-auto mb-12 space-y-4">
            <h2 className="text-4xl font-extrabold text-white">精選投資建議名單</h2>
            <p className="text-slate-400">系統自動篩選門檻：F-Score ≥ 5 | Z-Score > 2.5 | 現金流品質 ≥ 1.2</p>
          </div>
        )}

        {/* Selection & Screener Interface */}
        <div className={`mb-12 ${selectedStock ? 'max-w-xl' : 'max-w-full'}`}>
          <div className="relative group max-w-xl">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-slate-500 group-focus-within:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            <input
              type="text"
              className="block w-full pl-12 pr-4 py-4 bg-slate-900 border border-slate-700 rounded-2xl text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all shadow-xl"
              placeholder="輸入代碼或公司名稱進行篩選..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {!selectedStock && (
            <div className="mt-8 bg-slate-900/50 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-900 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <th className="px-6 py-4">公司代碼</th>
                    <th className="px-6 py-4">F-Score (≥5)</th>
                    <th className="px-6 py-4">Z-Score (>2.5)</th>
                    <th className="px-6 py-4">OCF 品質 (≥1.2)</th>
                    <th className="px-6 py-4">推薦原因</th>
                    <th className="px-6 py-4 text-center">投資狀態</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredSummary.map(({ stock, analysis, reason }) => (
                    <tr 
                      key={stock.symbol}
                      onClick={() => handleAnalysis(stock)}
                      className="hover:bg-slate-800/50 transition-colors cursor-pointer group"
                    >
                      <td className="px-6 py-5">
                        <div className="font-bold text-white group-hover:text-indigo-400 transition-colors">{stock.symbol}</div>
                        <div className="text-xs text-slate-500">{stock.name}</div>
                      </td>
                      <td className="px-6 py-5">
                        <span className={`font-mono text-lg ${analysis.fScore.total >= 5 ? 'text-emerald-400' : 'text-slate-400'}`}>
                          {analysis.fScore.total}/9
                        </span>
                      </td>
                      <td className="px-6 py-5">
                        <span className={`font-mono text-lg ${analysis.zScore.score > 2.5 ? 'text-emerald-400' : 'text-slate-400'}`}>
                          {analysis.zScore.score.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-6 py-5">
                        <span className={`font-mono text-lg ${analysis.cashFlow.ocfQuality >= 1.2 ? 'text-emerald-400' : 'text-slate-400'}`}>
                          {analysis.cashFlow.ocfQuality.toFixed(2)}x
                        </span>
                      </td>
                      <td className="px-6 py-5">
                        <span className="text-sm text-slate-300 font-medium">{reason}</span>
                      </td>
                      <td className="px-6 py-5 text-center">
                        {analysis.isInvestable ? (
                          <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-[10px] font-bold uppercase rounded-full border border-emerald-500/20">
                            推薦進場
                          </span>
                        ) : (
                          <span className="px-3 py-1 bg-slate-800 text-slate-500 text-[10px] font-bold uppercase rounded-full border border-slate-700">
                            觀望中
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Loading State */}
        {loading && !aiInterpretation && (
          <div className="flex flex-col items-center justify-center py-20 space-y-6">
            <div className="w-20 h-20 border-8 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
            <div className="text-center">
              <h3 className="text-xl font-bold text-white">啟動 AI 深度財務掃描</h3>
              <p className="text-slate-500">正在分析 {selectedStock?.symbol} 的各項財務細節與產業前景...</p>
            </div>
          </div>
        )}

        {/* Results */}
        {selectedStock && analysis && (
          <AnalysisView 
            stock={selectedStock} 
            analysis={analysis} 
            aiInterpretation={aiInterpretation} 
          />
        )}
      </main>

      <footer className="mt-20 border-t border-slate-900 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 grayscale opacity-50">
            <div className="bg-slate-700 p-1 rounded">
               <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            </div>
            <span className="font-bold text-slate-400 text-sm">CODE GYM ANALYTICS</span>
          </div>
          <div className="text-slate-600 text-xs text-center md:text-right">
            專業財報終端系統 © 2024. 已更新門檻：F-Score ≥ 5 | Z-Score > 2.5
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
