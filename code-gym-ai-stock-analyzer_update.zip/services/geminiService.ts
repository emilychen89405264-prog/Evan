
import { GoogleGenAI, Type } from "@google/genai";
import { StockData, AnalysisSummary, AIAnalysisResponse, GroundingSource } from '../types';

export async function getAIInterpretation(stock: StockData, analysis: AnalysisSummary): Promise<AIAnalysisResponse> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    你是一位精通全球股市的專業分析師。請使用 Google Search 搜尋並提供 ${stock.symbol} (${stock.name}) 的「目前最新即時股價」與「最新總市值」。
    
    接著，請針對以下財務指標進行深度分析：
    - 板塊: ${stock.sector} | 產業: ${stock.industry}
    - Piotroski F-Score: ${analysis.fScore.total}/9
    - Altman Z-Score: ${analysis.zScore.score.toFixed(2)}
    - 杜邦 ROE: ${(analysis.duPont[0].roe * 100).toFixed(2)}%
    
    請以「繁體中文」提供分析報告，並嚴格遵守以下 JSON 格式：
    {
      "livePrice": 數字 (目前的最新股價),
      "liveMarketCap": "字串 (目前的最新總市值，如 3.4 兆美元)",
      "mainStrengths": ["主要優勢1", "主要優勢2", ...],
      "riskFactors": ["風險因素1", "風險因素2", ...],
      "monitoringMetrics": ["監控指標1", "監控指標2", ...],
      "industryOutlook": "未來 2 年產業趨勢解讀"
    }
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          livePrice: { type: Type.NUMBER },
          liveMarketCap: { type: Type.STRING },
          mainStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
          riskFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
          monitoringMetrics: { type: Type.ARRAY, items: { type: Type.STRING } },
          industryOutlook: { type: Type.STRING }
        },
        required: ["livePrice", "liveMarketCap", "mainStrengths", "riskFactors", "monitoringMetrics", "industryOutlook"]
      }
    }
  });

  // 提取 Grounding Sources
  const sources: GroundingSource[] = [];
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (chunks) {
    chunks.forEach((chunk: any) => {
      if (chunk.web && chunk.web.uri && chunk.web.title) {
        sources.push({
          title: chunk.web.title,
          uri: chunk.web.uri
        });
      }
    });
  }

  try {
    const data = JSON.parse(response.text);
    return { ...data, sources };
  } catch (error) {
    console.error("解析 AI 回應失敗:", error);
    return {
      livePrice: stock.currentPrice,
      liveMarketCap: "數據獲取中...",
      mainStrengths: ["獲利能力優異", "產業領導地位", "現金流穩健"],
      riskFactors: ["宏觀經濟風險", "產業競爭激烈"],
      monitoringMetrics: ["營收成長率", "毛利率變化"],
      industryOutlook: "產業前景看好，預計未來兩年將持續增長。",
      sources
    };
  }
}
