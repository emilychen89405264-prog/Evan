
import { 
  FinancialYear, 
  StockData, 
  FScoreResult, 
  ZScoreResult, 
  DuPontResult, 
  CashFlowResult, 
  AnalysisSummary 
} from '../types';

export function calculateFScore(latest: FinancialYear, previous: FinancialYear): FScoreResult {
  const roaLatest = latest.netIncome / latest.totalAssets;
  const roaPrev = previous.netIncome / previous.totalAssets;
  
  const details = {
    roaPositive: roaLatest > 0,
    ocfPositive: latest.operatingCashFlow > 0,
    roaImproving: roaLatest > roaPrev,
    ocfVsNetIncome: latest.operatingCashFlow > latest.netIncome,
    leverageDecreasing: (latest.longTermDebt / latest.totalAssets) < (previous.longTermDebt / previous.totalAssets),
    liquidityImproving: (latest.currentAssets / latest.currentLiabilities) > (previous.currentAssets / previous.currentLiabilities),
    sharesNoDilution: latest.sharesOutstanding <= previous.sharesOutstanding,
    marginImproving: (latest.grossProfit / latest.revenue) > (previous.grossProfit / previous.revenue),
    turnoverImproving: (latest.revenue / latest.totalAssets) > (previous.revenue / previous.totalAssets),
  };

  const total = Object.values(details).filter(Boolean).length;
  return { total, details };
}

export function calculateZScore(latest: FinancialYear): ZScoreResult {
  const workingCapital = latest.currentAssets - latest.currentLiabilities;
  const ebit = latest.ebit; 
  
  const a = (workingCapital / latest.totalAssets);
  const b = (latest.retainedEarnings / latest.totalAssets);
  const c = (ebit / latest.totalAssets);
  const d = (latest.marketCap / latest.totalLiabilities);
  const e = (latest.revenue / latest.totalAssets);

  const score = 1.2 * a + 1.4 * b + 3.3 * c + 0.6 * d + 1.0 * e;

  let risk: 'Safe' | 'Grey' | 'Distress' = 'Distress';
  if (score > 2.5) risk = 'Safe';
  else if (score >= 1.81) risk = 'Grey';

  return { score, a, b, c, d, e, risk };
}

export function calculateDuPont(years: FinancialYear[]): DuPontResult[] {
  return years.map(y => {
    const netMargin = y.netIncome / y.revenue;
    const assetTurnover = y.revenue / y.totalAssets;
    const equityMultiplier = y.totalAssets / y.shareholdersEquity;
    const roe = netMargin * assetTurnover * equityMultiplier;
    return { year: y.year, netMargin, assetTurnover, equityMultiplier, roe };
  });
}

export function calculateCashFlow(latest: FinancialYear): CashFlowResult {
  const ocfQuality = latest.operatingCashFlow / latest.netIncome;
  const fcf = latest.operatingCashFlow - Math.abs(latest.capitalExpenditure);
  
  const totalCF = Math.abs(latest.operatingCashFlow) + Math.abs(latest.investingCashFlow) + Math.abs(latest.financingCashFlow);
  
  return {
    ocfQuality,
    fcf,
    structure: {
      operating: latest.operatingCashFlow / totalCF,
      investing: latest.investingCashFlow / totalCF,
      financing: latest.financingCashFlow / totalCF
    }
  };
}

export function performFullAnalysis(stock: StockData): AnalysisSummary {
  const latest = stock.financials[0];
  const previous = stock.financials[1];

  const fScore = calculateFScore(latest, previous);
  const zScore = calculateZScore(latest);
  const duPont = calculateDuPont(stock.financials);
  const cashFlow = calculateCashFlow(latest);

  // Updated Criteria per user request:
  // F-Score >= 5 (further down from 6)
  // Z-Score > 2.5
  // OCF Quality >= 1.2
  const isInvestable = (fScore.total >= 5) && (zScore.score > 2.5) && (cashFlow.ocfQuality >= 1.2) && (latest.marketCap > 1000000000);

  return {
    fScore,
    zScore,
    duPont,
    cashFlow,
    isInvestable
  };
}
