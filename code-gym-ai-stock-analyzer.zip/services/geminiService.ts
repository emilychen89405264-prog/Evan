
import { GoogleGenAI, Type } from "@google/genai";
import { StockData, AnalysisSummary, AIAnalysisResponse } from '../types';

export async function getAIInterpretation(stock: StockData, analysis: AnalysisSummary): Promise<AIAnalysisResponse> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are a world-class financial analyst. Analyze the following stock and its financial framework results:
    
    Stock: ${stock.name} (${stock.symbol})
    Sector: ${stock.sector}
    Industry: ${stock.industry}
    
    Analysis Results:
    - Piotroski F-Score: ${analysis.fScore.total}/9
    - Altman Z-Score: ${analysis.zScore.score.toFixed(2)} (${analysis.zScore.risk})
    - DuPont ROE (Latest): ${(analysis.duPont[0].roe * 100).toFixed(2)}%
    - OCF Quality Ratio: ${analysis.cashFlow.ocfQuality.toFixed(2)}
    - Free Cash Flow: $${(analysis.cashFlow.fcf / 1e6).toFixed(0)}M
    
    Provide a professional investment interpretation focusing on:
    1. 3-5 key strengths based on these figures.
    2. Critical risk factors to monitor.
    3. Key metrics to track in the next 12 months.
    4. Industry outlook for the next 2 years for the ${stock.industry} sector.
    
    Format your response as a JSON object matching the defined schema.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          mainStrengths: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "List of 3-5 main financial strengths."
          },
          riskFactors: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Potential risk factors."
          },
          monitoringMetrics: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Metrics to track for future performance."
          },
          industryOutlook: {
            type: Type.STRING,
            description: "2-year outlook for the industry."
          }
        },
        required: ["mainStrengths", "riskFactors", "monitoringMetrics", "industryOutlook"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Failed to parse AI response:", error);
    return {
      mainStrengths: ["Strong profitability trends", "Healthy liquidity", "Efficient asset utilization"],
      riskFactors: ["Market volatility", "Industry competition", "Macroeconomic headwinds"],
      monitoringMetrics: ["Revenue growth consistency", "Operating margin stability", "Inventory turnover rates"],
      industryOutlook: "The industry is expected to see moderate growth driven by technological advancements and shifting consumer preferences over the next two years."
    };
  }
}
